import boto3

def lambda_handler(event, context):
    
    dms = boto3.client('dms')
    
    
    migration_task_arns = ['arn:aws:dms:us-east-1:958908842097:task:7NOQFSGUUO2CN3SEBORD6HJHAFKN6XL55AG6TUA','arn:aws:dms:us-east-1:958908842097:task:N6PUHTM25T24OP3K6VIEDAGZRIPKOC37B3DUVPA','arn:aws:dms:us-east-1:958908842097:task:EP6NKEVWGWVRVQCSBBIAAHBXKWHVKN3W3X3X74Y']
    
    
    for migration_task_arn in migration_task_arns:
        result = dms.start_replication_task(
            ReplicationTaskArn=migration_task_arn,
            StartReplicationTaskType='reload-target'
        )

    return "Migration tasks started successfully "
